# Security Policy

## Supported Versions

AxsolyOS is currently under active development. Support is limited before AxsolyOS reaches v1.0.

## Reporting a Vulnerability

If you see any vulnerabiility, email us at wiki@axsolyos.io
