package drivers

import (
	_ "github.com/IceWhaleTech/AxsolyOS/drivers/dropbox"
	_ "github.com/IceWhaleTech/AxsolyOS/drivers/google_drive"
	_ "github.com/IceWhaleTech/AxsolyOS/drivers/onedrive"
)

// All do nothing,just for import
// same as _ import
func All() {

}
