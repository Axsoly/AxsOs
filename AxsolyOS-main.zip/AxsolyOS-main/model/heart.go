package model

type AxsolyOSHeart struct {
	UuId string `json:"uuid"`
	Type string `json:"type"`
}
