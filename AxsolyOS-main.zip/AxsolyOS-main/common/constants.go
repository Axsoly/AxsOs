package common

const (
	SERVICENAME = "axsolyos"
	VERSION     = "0.4.15"
	BODY        = " "
	RANW_NAME   = "IceWhale-RemoteAccess"
)
