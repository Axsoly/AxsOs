package v2

import (
	"github.com/IceWhaleTech/AxsolyOS/codegen"
	"github.com/IceWhaleTech/AxsolyOS/service"
)

type AxsolyOS struct {
	fileUploadService *service.FileUploadService
}

func NewAxsolyOS() codegen.ServerInterface {
	return &AxsolyOS{
		fileUploadService: service.NewFileUploadService(),
	}
}
